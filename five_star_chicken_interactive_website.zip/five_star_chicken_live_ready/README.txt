FIVE STAR CHICKEN – PANTOK, BINANGONAN
Website package: responsive, interactive static website.

PREVIEW
Open index.html in a browser. Keep the assets folder beside it.

INTERACTIONS
- Mobile navigation menu
- Menu filters: All, Chicken, Meals & Favorites, Tempura
- Product detail pop-ups
- Click-to-call and SMS bulk inquiry links
- Foodpanda branch listing link
- GrabFood search entry point

SOURCE ACCURACY
The displayed selections are based on the supplied Facebook screenshots and the user's requested Butterfly Chicken item:
Roasted Chicken, Butterfly Chicken, Fried Chicken, Chicken Sisig, Rice Meals, Shrimp Tempura, Tempura, Chicken Roll.
No fries or chicken tenders are included. No menu prices are invented.
Food images are crops from the supplied screenshot, so replace them with original high-resolution product photographs when available.

BEFORE GOING PUBLIC
1. Confirm operating hours (this version uses the Facebook post's 7:00 AM–10:00 PM).
2. Replace the general GrabFood link with the exact branch store URL when available.
3. Confirm every menu selection and its availability with the branch.
4. For a free public URL, upload index.html and the assets folder to a GitHub repository, then enable Settings > Pages > Deploy from a branch > main > /(root).
This package is ready for preview and static hosting, but has not been published to a public domain.
